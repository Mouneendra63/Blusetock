export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user' | 'moderator';
  avatar: string;
  createdAt: string;
  lastActive: string;
  status: 'active' | 'inactive';
}

export interface DashboardStats {
  totalUsers: number;
  activeUsers: number;
  revenue: number;
  growth: number;
}

export interface ChartData {
  name: string;
  value: number;
  color?: string;
}

export interface Activity {
  id: string;
  user: string;
  action: string;
  timestamp: string;
  type: 'login' | 'signup' | 'purchase' | 'update';
}