import React, { useState, useEffect } from 'react';
import { TrendingUp, Users, Eye, MousePointer, Calendar, Filter } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';
import Card from '../components/UI/Card';
import StatCard from '../components/UI/StatCard';
import LoadingSpinner from '../components/UI/LoadingSpinner';

interface AnalyticsData {
  pageViews: { name: string; views: number; unique: number }[];
  userBehavior: { name: string; value: number; color: string }[];
  trafficSources: { name: string; visitors: number; percentage: number }[];
  weeklyTrend: { day: string; visitors: number; pageViews: number }[];
}

const Analytics: React.FC = () => {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('7d');

  useEffect(() => {
    // Simulate API call
    const fetchAnalytics = async () => {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      setData({
        pageViews: [
          { name: 'Home', views: 12450, unique: 8900 },
          { name: 'Dashboard', views: 8920, unique: 6200 },
          { name: 'Products', views: 7330, unique: 5100 },
          { name: 'Profile', views: 5420, unique: 4200 },
          { name: 'Settings', views: 3210, unique: 2800 }
        ],
        userBehavior: [
          { name: 'New Users', value: 65, color: '#3b82f6' },
          { name: 'Returning Users', value: 35, color: '#10b981' }
        ],
        trafficSources: [
          { name: 'Direct', visitors: 4200, percentage: 42 },
          { name: 'Search', visitors: 3100, percentage: 31 },
          { name: 'Social', visitors: 1800, percentage: 18 },
          { name: 'Referral', visitors: 900, percentage: 9 }
        ],
        weeklyTrend: [
          { day: 'Mon', visitors: 2400, pageViews: 4800 },
          { day: 'Tue', visitors: 1800, pageViews: 3600 },
          { day: 'Wed', visitors: 2200, pageViews: 4400 },
          { day: 'Thu', visitors: 2800, pageViews: 5600 },
          { day: 'Fri', visitors: 3200, pageViews: 6400 },
          { day: 'Sat', visitors: 2600, pageViews: 5200 },
          { day: 'Sun', visitors: 2000, pageViews: 4000 }
        ]
      });
      setLoading(false);
    };

    fetchAnalytics();
  }, [timeRange]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
          <p className="text-gray-600">Track your website performance and user behavior</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
            <option value="90d">Last 90 days</option>
          </select>
          <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Page Views"
          value="24,567"
          change="+14% from last period"
          changeType="positive"
          icon={Eye}
          iconColor="text-blue-600"
        />
        <StatCard
          title="Unique Visitors"
          value="18,432"
          change="+8% from last period"
          changeType="positive"
          icon={Users}
          iconColor="text-green-600"
        />
        <StatCard
          title="Avg. Session Duration"
          value="3m 24s"
          change="+12% from last period"
          changeType="positive"
          icon={Calendar}
          iconColor="text-purple-600"
        />
        <StatCard
          title="Bounce Rate"
          value="34.5%"
          change="-2.1% from last period"
          changeType="positive"
          icon={MousePointer}
          iconColor="text-orange-600"
        />
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Trend */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Weekly Traffic Trend</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data?.weeklyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="day" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#ffffff', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }} 
                />
                <Area 
                  type="monotone" 
                  dataKey="visitors" 
                  stackId="1" 
                  stroke="#3b82f6" 
                  fill="#3b82f6" 
                  fillOpacity={0.6}
                />
                <Area 
                  type="monotone" 
                  dataKey="pageViews" 
                  stackId="1" 
                  stroke="#10b981" 
                  fill="#10b981" 
                  fillOpacity={0.6}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* User Behavior */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">User Behavior</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data?.userBehavior}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {data?.userBehavior.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center space-x-6 mt-4">
            {data?.userBehavior.map((item, index) => (
              <div key={index} className="flex items-center space-x-2">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-sm text-gray-600">{item.name}: {item.value}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Page Views and Traffic Sources */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Pages */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Pages</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data?.pageViews} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis type="number" stroke="#6b7280" />
                <YAxis dataKey="name" type="category" stroke="#6b7280" width={80} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#ffffff', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }} 
                />
                <Bar dataKey="views" fill="#3b82f6" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Traffic Sources */}
        <Card>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Traffic Sources</h3>
          <div className="space-y-4">
            {data?.trafficSources.map((source, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${
                    index === 0 ? 'bg-blue-500' : 
                    index === 1 ? 'bg-green-500' : 
                    index === 2 ? 'bg-purple-500' : 'bg-orange-500'
                  }`} />
                  <span className="font-medium text-gray-900">{source.name}</span>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">{source.visitors.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">{source.percentage}%</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Analytics;