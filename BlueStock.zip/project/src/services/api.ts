import { User, DashboardStats, ChartData, Activity } from '../types';

// Mock data
const mockUsers: User[] = [
  {
    id: '1',
    name: 'Alice Johnson',
    email: 'alice@example.com',
    role: 'admin',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
    createdAt: '2024-01-15',
    lastActive: '2024-12-16',
    status: 'active'
  },
  {
    id: '2',
    name: 'Bob Smith',
    email: 'bob@example.com',
    role: 'user',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
    createdAt: '2024-02-20',
    lastActive: '2024-12-15',
    status: 'active'
  },
  {
    id: '3',
    name: 'Carol Davis',
    email: 'carol@example.com',
    role: 'moderator',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
    createdAt: '2024-03-10',
    lastActive: '2024-12-14',
    status: 'inactive'
  },
  {
    id: '4',
    name: 'David Wilson',
    email: 'david@example.com',
    role: 'user',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
    createdAt: '2024-04-05',
    lastActive: '2024-12-16',
    status: 'active'
  }
];

const mockStats: DashboardStats = {
  totalUsers: 1247,
  activeUsers: 892,
  revenue: 45920,
  growth: 12.5
};

const mockChartData: ChartData[] = [
  { name: 'Jan', value: 4000 },
  { name: 'Feb', value: 3000 },
  { name: 'Mar', value: 5000 },
  { name: 'Apr', value: 4500 },
  { name: 'May', value: 6000 },
  { name: 'Jun', value: 5500 }
];

const mockActivities: Activity[] = [
  {
    id: '1',
    user: 'Alice Johnson',
    action: 'Updated profile settings',
    timestamp: '2 minutes ago',
    type: 'update'
  },
  {
    id: '2',
    user: 'Bob Smith',
    action: 'Completed purchase',
    timestamp: '15 minutes ago',
    type: 'purchase'
  },
  {
    id: '3',
    user: 'Carol Davis',
    action: 'Signed up',
    timestamp: '1 hour ago',
    type: 'signup'
  },
  {
    id: '4',
    user: 'David Wilson',
    action: 'Logged in',
    timestamp: '2 hours ago',
    type: 'login'
  }
];

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const api = {
  async getUsers(): Promise<User[]> {
    await delay(500);
    return [...mockUsers];
  },

  async getUser(id: string): Promise<User | null> {
    await delay(300);
    return mockUsers.find(user => user.id === id) || null;
  },

  async createUser(userData: Omit<User, 'id' | 'createdAt'>): Promise<User> {
    await delay(600);
    const newUser: User = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString().split('T')[0]
    };
    mockUsers.push(newUser);
    return newUser;
  },

  async updateUser(id: string, userData: Partial<User>): Promise<User | null> {
    await delay(500);
    const index = mockUsers.findIndex(user => user.id === id);
    if (index === -1) return null;
    
    mockUsers[index] = { ...mockUsers[index], ...userData };
    return mockUsers[index];
  },

  async deleteUser(id: string): Promise<boolean> {
    await delay(400);
    const index = mockUsers.findIndex(user => user.id === id);
    if (index === -1) return false;
    
    mockUsers.splice(index, 1);
    return true;
  },

  async getDashboardStats(): Promise<DashboardStats> {
    await delay(300);
    return { ...mockStats };
  },

  async getChartData(): Promise<ChartData[]> {
    await delay(400);
    return [...mockChartData];
  },

  async getRecentActivity(): Promise<Activity[]> {
    await delay(200);
    return [...mockActivities];
  }
};